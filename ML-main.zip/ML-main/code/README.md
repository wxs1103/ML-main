
<!-- README.md is generated from README.Rmd. Please edit that file -->

Data and code description
------------
Data description:
geoMatrix1.txt contains gene expression profiles for all samples included in the study (sepsis samples and control samples). Each row represents a sample. Each column represents a gene.
"S.xt" contains the above sample name and its corresponding label (0 for control group, 1 for disease group).
Script description:
The scripts involved in this document include data_split.ipynb and machine_learning.ipynb. The function of the data_split.ipynb script is to divide the gene expression profile containing control and sepsis samples (" geoMatrix1.txt ") into a training set and a test set. They can also pick out gene sets of interest. So you should run the script first. The output files of the script are "x_train.txt", "x_test.txt", "y_train.txt", and "y_test.txt ", which represent the expression profile data and corresponding labels of the gene sets of interest in the training set and the test set, respectively.
The function of the "machine_learning.ipynb" script is to train and test a variety of machine learning models. The input file is the output file of the data_split.ipynb script. The output results include the output files of different machine learning models and the ROC curves of the models.

